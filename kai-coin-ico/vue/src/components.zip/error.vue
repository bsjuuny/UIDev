<template>
	<div class="server-error">
		<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503474598/KaicoinICO/web/icon-error.png" class="icon-error" alt="" />
		<h1>죄송합니다.</h1>
		<p class="error-message">요청하신 페이지를 찾을 수 없습니다.<br />
		입력하신 주소와 경로가 정확한지 확인해주세요!</p>
		<ul class="page-move">
			<li><a href="" class="button-prev" v-on:click="pageBack">이전화면</a></li>
			<li><router-link :to="{ path: '/'}" class="button-home">KAICOIN 초기화면</router-link></li>
		</ul>
	</div>
</template>

<script>
	export default {
		data: function() {
			return {
			}
		},
		mounted: function() {
			$('header').hide();
		},
		methods: {
			pageBack: function() {
				window.history.back();
			}
		}
	}
</script>