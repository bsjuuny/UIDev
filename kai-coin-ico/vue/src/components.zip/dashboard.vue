<template>
	<div class="dashboard">
		<h2 class="blind">kaicoin ICO Infomation</h2>
		<div class="time-infomation">
			<span class="end-infomation">2017.10.31 종료(GMT +9시간)</span>
			<div class="end-countdown">
				<p class="count-time"></p>
				<span class="date day">D</span>
				<span class="date hour">H</span>
				<span class="date minute">M</span>
				<span class="date second">S</span>
			</div>
			<p class="exchange-infomation"><em>1,500 KAI = 1 ETH</em></p>
		</div>
		<div class="ico-infomation">
			<dl class="ico-data">
				<dt>판매량</dt>
				<dd><em>0</em> <span class="total-sell">/ 2,000,000,000</span></dd>
				<dt>참여인원</dt>
				<dd>
					<div class="ready">
						<span class="total-sell">집계 중입니다.</span>
					</div>
					<div class="person">
						<span class="ico-person">850</span> <span class="text-small">명</span>
					</div>
				</dd>
				<dt>총 투자금액</dt>
				<dd>
					<div class="ready">
						<span class="total-sell">집계 중입니다.</span>
					</div>
					<div class="price">
						<p><span class="ico-kai">12,345,678</span> <span class="text-small">KAI</span></p>
						<p><span class="ico-eth">5,678</span> <span class="text-small">ETH</span></p>
					</div>
				</dd>
			</dl>
		</div>
		<div class="ico-bonus">
			<h3>보너스</h3>
			<div class="bonus-timetable">
				<p class="week one">1주차 + 20%</p>
				<p class="week two">2주차 + 15%</p>
				<p class="week three">3주차 + 10%</p>
				<p class="week four">4주차 + 5%</p>
				<p class="week five">5주차 + 0%</p>
			</div>
		</div>
		<div class="ico-buy-address">
			<h3>코인 구매 주소</h3>
			<ul class="address-detail-infomation">
				<li class="address">0x더미주소 QR코드 더미</li>
				<li><button type="button" class="button-copy-url" data-clipboard-target=".address">주소복사하기</button> <span></span></li>
				<li class="infomation">※ 거래소에서 보내시면 안됩니다. 이더리움 개인지갑에서 보내주세요.<br />
				코인 구매 시 최소금액은 150 KAI (0.1ETH)</li>
			</ul>
			<img src="../assets/dummyQr.png" class="qrcode" alt="Eth QrCode" />
		</div>
		<div class="ico-investment-application-form">
			<h3>카이코인 ICO 투자신청서</h3>
			<p class="investment-infomation">참여하신 ETH 주소를 입력해주세요.</p>
			<div class="input-form">
				<input type="text" /><button type="button">신청완료</button>
				<span class="error">없는 주소 입니다.</span>
			</div>
			<p class="send-ethereum-infomation">※ 신청완료 후 기재하신 이더리움 주소에서 위의 코인구매주소로 이더리움을 보내주세요.</p>
		</div>
		<div class="ico-investment-application-form">
			<h3>카이코인 ICO 참여 확인</h3>
			<p class="investment-infomation">참여하신 ETH 주소를 입력해주세요.</p>
			<div class="input-form">
				<input type="text" /><button type="button">확인</button>
			</div>
			<p class="check-ethereum-infomation">참여하신 주소 <em class="wallet">0xd2982ba909a717bf59851b7a82e86b342380f9c2</em> 로 <em><span class="eth">0.5</span> ETH 참여가 확인</em> 되었습니다.<br />
			자세한 내용은 ICO Presale 기간 종료 후 재안내 드리겠습니다.<br />
			참여해주셔서 감사드립니다.</p>
			<p class="check-ethereum-infomation tablet">참여하신 주소<br />
			<em class="wallet">0xd2982ba909a717bf59851b7a82e86b342380f9c2</em> 로<br />
			<em><span class="eth">0.5</span> ETH 참여가 확인</em> 되었습니다.<br />
			자세한 내용은 ICO Presale 기간 종료 후 재안내 드리겠습니다.<br />
			참여해주셔서 감사드립니다.</p>
		</div>
	</div>
</template>

<script>
	export default {
		name: '',
		data () {
			return {
			}
		},
		created: function () {
		},
		mounted: function () {
			$('body').addClass('background-gray').removeClass('main');
			$('header').removeClass('main');

			var clipboard = new Clipboard('.button-copy-url');
			clipboard.on('success', function(e) {
				e.clearSelection();
				$('.button-copy-url ~ span').addClass('active');
			});

			this.dateCountdown();
			this.bonusTimeLine();
		},
		methods: {
			dateCountdown: function() {
				var icoDate = moment.tz("2017-10-31 12:00", "asia/seoul");
				$('.end-countdown .count-time').countdown(icoDate.toDate()).on('update.countdown', function(event) {
					$(this).text(event.strftime('%D : %H : %M : %S'));
				}).on('finish.countdown', function(event) {
					$(this).text(event.strftime('00 : 00 : 00 : 00'));
				});
			},
			bonusTimeLine: function() {
				var startdate1 = moment.tz("2017-09-01 12:00:00", "asia/seoul"),
					enddate1 = moment.tz("2017-09-08 11:59:59", "asia/seoul"),

					startdate2 = moment.tz("2017-09-08 12:00:00", "asia/seoul"),
					enddate2 = moment.tz("2017-09-15 11:59:59", "asia/seoul"),

					startdate3 = moment.tz("2017-09-15 12:00:00", "asia/seoul"),
					enddate3 = moment.tz("2017-09-22 11:59:59", "asia/seoul"),

					startdate4 = moment.tz("2017-09-22 12:00:00", "asia/seoul"),
					enddate4 = moment.tz("2017-09-29 11:59:59", "asia/seoul"),

					startdate5 = moment.tz("2017-09-29 12:00:00", "asia/seoul");

				$('.bonus-timetable .week').removeClass('active');
				if (moment().isBetween(startdate1, enddate1)) {
					$('.bonus-timetable').find('.one').addClass('active');
				} else if (moment().isBetween(startdate2, enddate2)) {
					$('.bonus-timetable').find('.two').addClass('active');
				} else if (moment().isBetween(startdate3, enddate3)) {
					$('.bonus-timetable').find('.three').addClass('active');
				} else if (moment().isBetween(startdate4, enddate4)) {
					$('.bonus-timetable').find('.four').addClass('active');
				} else if (moment().isAfter(startdate5)) {
					$('.bonus-timetable').find('.five').addClass('active');
				};
			}
		}
	}
</script>