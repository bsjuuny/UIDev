<template>
	<form action="./" method="post" v-on:submit.prevent="login">
	<fieldset>
		<legend>Login</legend>
		<section class="section-login">
			<h1>카이코인 로그인</h1>
			<div class="input-email">
				<h2><label for="loginEmail">이메일</label></h2>
				<input type="text" id="loginEmail" placeholder="yourmail@address.com" />
				<span class="icon-email"></span>
			</div>
			<!-- 패스워드 입력 -->
			<div class="input-password">
				<h2><label for="loginPassword">비밀번호</label></h2>
				<input type="password" id="loginPassword" placeholder="password" />
				<span class="icon-password"></span>
			</div>
			<!-- 패스워드 에러 -->
			<!-- <div class="input-password error">
				<h2><label for="loginPassword">비밀번호</label></h2>
				<input type="password" id="loginPassword" placeholder="password" />
				<span class="icon-password"></span>
			</div> -->
			<div class="login-service">
				<ul class="login-menu">
					<li class="find-password"><router-link :to="{ path: 'resetPasswordEmail'}">비밀번호 찾기</router-link></li>
					<li class="join"><router-link :to="{ path: 'join'}">회원가입</router-link></li>
				</ul>
				<button type="submit" class="button-login">로그인</button>
			</div>
		</section>
	</fieldset>
	</form>
</template>

<script>
var Axios = require('axios');
var SHA256 = require("crypto-js/sha256");

	export default {
		name: 'login',
		data: function() {
			return {
				isLoging: false,
				email: String,
				password: String,
				errors: []
			}
		},
		mounted: function () {
			$('body').addClass('background-gray').removeClass('main');
			$('header').removeClass('main');

			$('.input-password input').on({
				focus: function() {
					$(this).next('.icon-password').addClass('focus');
				},
				blur: function() {
					$(this).next('.icon-password').removeClass('focus');	
				}
			});
		},
		methods: {
			login: function() {
				this.email = $('#loginEmail').val();
				this.password = SHA256($('#loginPassword').val()).toString();

				if(this.email!='' && this.password!=''){
					this.toLogin();
				}
			},
			toLogin: function() {
				var obj = new Object();
				obj.email = this.email;
				obj.password = this.password;

				var json_data = JSON.stringify(obj);

				var settings = {
					async: false,
					crossDomain: true,
					url: "http://api.kaicoin.co.kr/auth/signin",
					method: "POST",
					// xhrFields: { withCredentials:true },
					headers: {
						"content-type": "application/json; charset=utf-8"
					},
					// ifModified: true,
					processData: true,
					data: json_data,
					success : function(data, status, response) {
						if (data) {
							// this.isLoging = true;
							// var value = data.email;

							// let expireDays = 1000 * 60 * 60 * 24 * 1;
							// this.setCookie('login', value, expireDays);

							// var cookietoSet=response.getAllResponseHeaders();
							// alert(cookietoSet);
							// console.log(data, status, response.json);

							console.log(this.$cookie.get('Header'));
							console.log(response);
							console.log(response.getResponseHeader('Authorization'));
							console.log(response.getResponseHeader('Cookies'));
							console.log(response.getResponseHeader('Cookies.X-Auth-Token'));
							console.log(response.getAllResponseHeaders());
							// console.log(response.Cookie());
							// this.$router.push('/dashboard');
						}
					}.bind(this),
					error : function(request, status, error) {
						// console.log(status);
						// console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
						// location.href = "/login"
					},
					complete: function(jqXHR, textStatus) {
						// console.log(jqXHR.getAllResponseHeaders(), textStatus);
					}
				}
				$.ajax(settings).done(function (response) {
					// console.log('1');
					// console.log(response);
					// console.log(response.getAllResponseHeaders());
				});

			}
		}
	}
</script>