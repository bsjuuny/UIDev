<template>
	<form action="./" method="post">
	<fieldset>
		<legend>이메일 확인</legend>
		<section class="section-reset">
			<h1>비밀번호 재설정</h1>
			<h2>새 비밀번호를 입력하세요.</h2>
			<div class="input-password">
				<h3><label for="inputPassword">새 비밀번호 (8자 이상 입력)</label></h3>
				<input type="password" id="inputPassword" placeholder="" />
				<h3><label for="inputCheckPassword">새 비밀번호 확인</label></h3>
				<input type="password" id="inputCheckPassword" placeholder="" />
			</div>
			<div class="button-right">
				<button type="button" class="button-check-email">재설정</button>
			</div>
		</section>
	</fieldset>
	</form>
</template>

<script>
	export default {
		name: 'smsCertification',
		data: function() {
			return {
				
			}
		},
		mounted: function () {
			$('body').addClass('background-gray').removeClass('main');
			$('header').removeClass('main');
		},
		methods: {
			
		}
	}

	$(function() {

	});
</script>