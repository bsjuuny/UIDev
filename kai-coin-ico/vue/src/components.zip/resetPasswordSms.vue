<template>
	<form action="./" method="post">
	<fieldset>
		<legend>이메일 확인</legend>
		<section class="section-reset">
			<h1>비밀번호 재설정</h1>
			<p class="sms-infomation">SMS로 발송된 코드를 입력하시면 새 비밀번호 사용이 가능합니다.</p>
			<div class="input-password">
				<h3><label for="inputPassword">코드입력</label></h3>
				<input type="password" id="inputPassword" class="input-certification-number" placeholder="" />
				<span class="certification-count"></span>
			</div>
			<div class="certification-navigator">
				<button type="button" class="button-resend-sms" disabled="disabled" v-on:click="checkSms">SMS 재전송</button>
				<button type="button" class="button-certification-complete">입력완료</button>
			</div>
		</section>
	</fieldset>
	</form>
</template>

<script>
	export default {
		name: 'smsCertification',
		data: function() {
			return {
				
			}
		},
		mounted: function () {
			$('body').addClass('background-gray').removeClass('main');
			$('header').removeClass('main');

			this.checkSms();
		},
		methods: {
			checkSms: function() {
				var second = 1000;
				var minute = second * 60 * 5;
				var oneMinute = new Date().getTime() + minute;
				$('.certification-count').countdown(oneMinute).on('update.countdown', function(event) {
					$(this).text(event.strftime('%M:%S'));
					$(this).text(event.strftime('%M:%S')).closest('.section-reset').find('.input-certification-number').prop('disabled', false).end().find('.button-certification-complete').prop('disabled', false);
				}).on('finish.countdown', function(event) {
					$(this).text(event.strftime('%M:%S')).closest('.section-reset').find('.input-certification-number').prop('disabled', true).end().find('.button-certification-complete').prop('disabled', true);
					alert('시간이 초과 되었습니다.');
				});
			}
		}
	}

	$(function() {

	});
</script>