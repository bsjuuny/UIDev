<template>
	<form action="" method="post" v-on:submit.prevent="checkSubmitForm">
	<fieldset>
		<legend>이메일 확인</legend>
		<section class="section-reset">
			<h1>비밀번호 재설정</h1>
			<h2>가입하실 메일주소를 입력하세요.</h2>
			<div class="input-email">
				<h3><label for="inputEmail">이메일</label></h3>
				<input type="text" id="inputEmail" placeholder="yourmail@address.com" v-model="getEmail" />
				<p class="error"></p>
			</div>
			<div class="button-right">
				<button type="submit" class="button-check-email">확인</button>
			</div>
		</section>
	</fieldset>
	</form>
</template>

<script>
	export default {
		name: 'smsCertification',
		data: function() {
			return {
				getEmail: ''
			}
		},
		mounted: function () {
			$('body').addClass('background-gray').removeClass('main');
			$('header').removeClass('main');
		},
		methods: {
			checkSubmitForm: function() {
				// var settings = {
				// 	"async": true,
				// 	"crossDomain": true,
				// 	"url": "http://api.kaicoin.co.kr/auth/validateEmail/"+this.getEmail+"/",
				// 	"method": "GET",
				// 	"headers": {},
					// success : function(data, status, response) {
					// 	this.$router.push({name: 'resetPasswordEmail'});
					// }.bind(this),
					// error : function(request, status, error) {
					// 	// console.log(error);
					// 	// location.href = "/resetPasswordEmail"
					// 	// this.$router.push({name: 'resetPasswordEmail'});
					// 	// console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
					// 	if (request.responseJSON.errorCode == 101) {
					// 		let expireDays = 1000 * 60 * 60 * 24 * 1;
					// 		this.setCookie('session', this.getEmail, expireDays);

					// 		this.$router.push({name: 'resetPassword'});	
					// 	}
					// }.bind(this)
				// }
				// $.ajax(settings);

				// 이메일 검증
				var objEmail1 = $('#inputEmail');
				var getEmail1 = objEmail1.val();

				var settings = {
					"async": true,
					"crossDomain": true,
					"url": "http://api.kaicoin.co.kr/auth/validateEmail/"+getEmail1+"/",
					"method": "GET",
					"headers": {},
					success : function(data, status, response) {
						this.$router.push({name: 'resetPasswordEmail'});
					}.bind(this),
					error : function(request, status, error) {
						// console.log(error);
						// location.href = "/resetPasswordEmail"
						// this.$router.push({name: 'resetPasswordEmail'});
						// console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
						if (request.responseJSON.errorCode == 101) {
							let expireDays = 1000 * 60 * 60 * 24 * 1;
							this.setCookie('email', this.getEmail, expireDays);

							this.$router.push({name: 'resetPassword'});	
						}
					}.bind(this)
				}

				if (!/^[a-z0-9_+.-]+@([a-z0-9-]+\.)+[a-z0-9]{2,4}$/.test(getEmail1)) {
					objEmail1.siblings('p.error').show().text('이메일 주소를 정확히 입력해 주세요.');
					objEmail1.addClass('error');
					return false;
				} else {
					$.ajax(settings);
				}
			}
		}
	}

	$(function() {

	});
</script>