<template>
	<form action="./" method="post" v-on:submit.prevent.stop="checkSubmitForm">
	<fieldset>
		<legend>회원가입</legend>
		<section class="section-join">
			<h1>카이코인 회원가입</h1>
			<ol class="join-step">
				<li class="active"><span>1</span> 이메일 인증</li>
				<li><span>2</span> 전화번호 인증</li>
			</ol>
			<!-- 잘못입력 했을 땐 error class 추가 -->
			<div class="join-email">
				<h2><label for="joinEmail">이메일</label></h2>
				<input type="text" id="joinEmail" placeholder="yourmail@address.com" v-on:blur="checkEmail" />
				<span class="checkOk"></span>
				<p class="error"></p>
			</div>
			<div class="join-name">
				<div class="left">
					<h2><label for="joinName">이름</label></h2>
					<input type="text" id="joinName" placeholder="이름" v-on:blur="checkName" />
					<p class="error"></p>
				</div>
				<div class="right">
					<h2><label for="joinFamilyName">성</label></h2>
					<input type="text" id="joinFamilyName" placeholder="성" v-on:blur="checkFamilyName" />
					<p class="error"></p>
				</div>
			</div>
			<div class="join-password">
				<h2><label for="joinPassword">비밀번호 (8자 이상 입력)</label></h2>
				<input type="password" id="joinPassword" placeholder="" v-on:blur="checkPassword" />
				<p class="error"></p>
				<h2 class="checkPassword"><label for="joinCheckPassword">비밀번호 확인</label></h2>
				<input type="password" id="joinCheckPassword" placeholder="" v-on:blur="recheckPassword" />
				<p class="error"></p>
			</div>
			<p class="agree-policy">
				<input type="checkbox" id="agree" v-on:change="checkTerm" /><span></span>
				<label for="agree">
					<a href="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503393214/KaicoinICO/web/GS_%EC%9D%B4%EC%9A%A9%EC%95%BD%EA%B4%80.pdf" target="_blank">서비스 이용약관</a>, <a href="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503558842/KaicoinICO/web/GS_%EA%B0%9C%EC%9D%B8%EC%A0%95%EB%B3%B4%EC%B7%A8%EA%B8%89%EB%B0%A9%EC%B9%A8.pdf" target="_blank">개인정보 취급방침</a>에 동의하며, 미국시민 또는 거주자가 아님을 확인합니다
				</label>
			</p>
			<div class="page-navigator">
				<router-link :to="{ path: 'login'}" class="button-login">로그인</router-link>
				<button type="submit" class="button-next">다음</button>
			</div>
		</section>
	</fieldset>
	</form>
</template>

<script>
var axios = require('axios');
var SHA256 = require("crypto-js/sha256");
var submitButton;

	export default {
		name: 'join',
		data: function() {
			return {
				email: String,
				name: String,
				familyName: String,
				password: String,
				errors: []
			}
		},
		mounted: function () {
			$('body').addClass('background-gray').removeClass('main');
			$('header').removeClass('main');

			submitButton = $('.page-navigator .button-next');
		},
		methods: {
			checkEmail: function() {
				// 이메일 검증
				var objEmail = $('#joinEmail');
				var getEmail = objEmail.val();
				var flag = false;

				if (!/^[a-z0-9_+.-]+@([a-z0-9-]+\.)+[a-z0-9]{2,4}$/.test(getEmail)) {
					objEmail.siblings('p.error').show().text('이메일 주소를 정확히 입력해 주세요.');
					objEmail.addClass('error');

					return false;
				}

				var settings = {
					async: false,
					crossDomain: true,
					url: "http://api.kaicoin.co.kr/auth/validateEmail/"+getEmail+"/",
					method: "GET",
					headers: {},
					error: function(request, status, error) {
						flag = false;
						// console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
						var code = request.responseJSON.errorCode;
						if (code === 101) {
							objEmail.siblings('p.error').show().text('이미 존재하는 이메일 입니다.');
							objEmail.addClass('error');
						} else if (code === 201) {
							objEmail.siblings('p.error').show().text('실제 존재하지 않는 이메일 입니다.');
							objEmail.addClass('error');
						}
					},
					success: function(data, status, response) {
						if (data) {
							flag = true;
							objEmail.siblings('p.error').hide();
							objEmail.removeClass('error');
							$('.join-email .checkOk').css('display', "block");
						}
					}
				}

				$.ajax(settings);
				this.email = objEmail.val();
				submitButton.prop('disabled', false);

				return flag;
			},
			checkName: function() {
				var objName = $('#joinName');
				var getName = objName.val().trim();

				if (getName === '') {
					objName.siblings('p.error').show().text('정확히 입력해 주세요.');
					objName.addClass('error');
					return false;
				}
				objName.siblings('p.error').hide();
				objName.removeClass('error');
				this.name = objName.val().trim();
				submitButton.prop('disabled', false);

				return true;
			},
			checkFamilyName: function() {
				var objFamilyName = $('#joinFamilyName');
				var getFamilyName = objFamilyName.val().trim();

				if (getFamilyName === '') {
					objFamilyName.siblings('p.error').show().text('정확히 입력해 주세요.');
					objFamilyName.addClass('error');
					return false;
				}
				objFamilyName.siblings('p.error').hide();
				objFamilyName.removeClass('error');
				this.familyName = objFamilyName.val().trim();
				submitButton.prop('disabled', false);

				return true;
			},
			checkPassword: function() {
				var objPassword = $('#joinPassword');
				var objEmail = $('#joinEmail');
				var getId = objEmail.val().split('@')[0];
				var getPwd = objPassword.val();

				if(!/^[a-zA-Z0-9]{8,20}$/.test(getPwd)){
					objPassword.next('p.error').show().text('숫자와 영문자 조합으로 8~20자리를 사용해야 합니다.');
					objPassword.addClass('error');
					return false;
				}

				var checkNumber = getPwd.search(/[0-9]/g);
				var checkEnglish = getPwd.search(/[a-z]/ig);

				if(checkNumber < 0 || checkEnglish < 0){
					objPassword.next('p.error').show().text('숫자와 영문자를 혼용하여야 합니다.');
					objPassword.addClass('error');
					return false;
				}

				if(getPwd.search(getId) > -1){
					objPassword.next('p.error').show().text('비밀번호에 아이디가 포함되었습니다.');
					objPassword.addClass('error');
					return false;
				}
				objPassword.next('p.error').hide();
				objPassword.removeClass('error');
				this.password = SHA256(objPassword.val()).toString();
				submitButton.prop('disabled', false);

				return true;
			},
			recheckPassword: function() {
				var objCheckPwd = $('#joinCheckPassword');
				var objPassword = $('#joinPassword');
				var checkPwd= objCheckPwd.val();
				var getPwd = objPassword.val();

				if (getPwd != checkPwd) {
					objCheckPwd.next('p.error').show().text('비밀번호가 다릅니다.');
					objCheckPwd.addClass('error');
					return false;
				}
				objCheckPwd.next('p.error').hide();
				objCheckPwd.removeClass('error');
				submitButton.prop('disabled', false);

				return true;
			},
			checkTerm: function() {
				if (!$('#agree').prop('checked')) {
					callPopup("약관에 동의해 주세요.", "error");
					return false;
				}
				submitButton.prop('disabled', false);

				return true;
			},
			checkSubmitForm: function() {
				$.blockUI({message: $('#loader'), centerY: true, css: {left:'50%', width:'200px', border:0, margin:'0 0 0 -100px'}});

				if (this.checkEmail() && this.checkName() && this.checkFamilyName() && this.checkPassword() && this.recheckPassword() && this.checkTerm()) {
					submitButton.prop('disabled', true);

					var obj = new Object();
					obj.email = this.email;
					obj.name1 = this.name;
					obj.name2 = this.familyName;
					obj.password = this.password;

					var json_data = JSON.stringify(obj);

					$.ajax({
						url:"http://api.kaicoin.co.kr/auth/signup",
						type:"post",
						contentType : "application/json; charset=UTF-8",
						dataType: "json",
						async: false,
						data:json_data,
						success : function(data, status, response) {
							var value = this.email;
							let expireDays = 1000 * 60 * 60 * 24 * 7;
							this.setCookie('join', value, expireDays);

							$.unblockUI();
							this.$router.push({name: 'sendMail'});
						}.bind(this),
						error: function(request, status, error) {
							// console.log(request.status);
							// console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
							// minsoonss@greenstage.co.kr
							$.unblockUI();
							submitButton.prop('disabled', false);
						}
					});
				} else {
					if (this.checkTerm()) {
						$.unblockUI();	
					}
					submitButton.prop('disabled', true);
				}
			},
			emailComplete: function() {
				this.$router.push({name: 'sendMail'});
			}
		}
	}
	function stck(str, limit, obj1) {
		var o, d, p, n = 0, l = limit == null ? 4 : limit;
		for (var i = 0; i < str.length; i++) {
			var c = str.charCodeAt(i);
			if (i > 0 && (p = o - c) > -2 && p < 2 && (n = p == d ? n + 1 : 0) > l - 3) {
			}
			d = p, o = c;
		}
	}

	function callPopup(popupMessage, state) {
		// 알림창 호출 - 확인 버튼 클릭시 동작은 index.js에서 
		$.blockUI({message: $('.popup'), centerY: true, css: {left:'50%', width:'320px', border:0, margin:'0 0 0 -160px'}});
		$('.popup .content').empty().append('<p>'+popupMessage+'</p>').closest('.popup').addClass(state);
	}
</script>