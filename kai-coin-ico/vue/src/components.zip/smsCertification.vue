<template>
	<form action="" method="post" v-on:submit.prevent="smsCertification">
	<fieldset>
		<legend>전화번호 인증</legend>
		<section class="section-join">
			<h1>카이코인 회원가입</h1>
			<ol class="join-step">
				<li><span>1</span> 이메일 인증</li>
				<li class="active"><span>2</span> 전화번호 인증</li>
			</ol>
			<h2 class="blind">전화번호 인증</h2>
			<div class="send-sms selectbox-parent">
				<a href="" class="design-selectbox">대한민국 +82</a>
				<!-- li a 선택시 selectbox 값도 함께 바뀜 -->
				<div class="div-selectbox">
					<ul>
						<li><a href="">대한민국 +82</a></li>
						<li><a href="">필리핀 +83</a></li>
						<li><a href="">중국 +86</a></li>
					</ul>
				</div>
				<!-- 모바일에서 show -->
				<select name="" id="" class="select-national" v-model="selectedCountry">
					<option value="82">대한민국 +82</option>
					<option value="83">필리핀 +83</option>
					<option value="86">중국 +86</option>
				</select>
				<!-- 인증요청시 disabled="disabled" 추가 -->
				<input type="number" class="input-phone-number" v-model="phoneNumber" placeholder="1012345678" />
				<p class="error"></p>
				<div class="button-right">
					<!-- 인증요청시 disabled="disabled" 추가 -->
					<button type="button" class="button-send-sms" v-on:click="checkSms">인증요청</button>
				</div>
			</div>
			<div class="resend-sms">
				<div class="certification">
					<h3><label for="certification-number">코드입력</label></h3>
					<input type="number" id="certification-number" class="input-certification-number" v-model="smsCertifyNumber" placeholder="" />
					<span class="certification-count"></span>
				</div>
				<div class="certification-navigator">
					<button type="button" class="button-resend-sms" disabled="disabled" v-on:click="resendSms">SMS 재전송</button>
					<button type="submit" class="button-certification-complete">입력완료</button>
				</div>
			</div>

		</section>
	</fieldset>
	</form>
</template>

<script>
	export default {
		name: 'smsCertification',
		data: function() {
			return {
				phoneNumber: Number,
				selectedCountry: 82,
				smsCertifyNumber: Number
			}
		},
		mounted: function () {
			$('body').addClass('background-gray').removeClass('main');
			$('header').removeClass('main');
		},
		methods: {
			checkSms: function () {
				if (this.phoneNumber != Number) {
					$('.input-phone-number').siblings('p.error').hide();
					this.toCheckSms();
				} else {
					$('.input-phone-number').siblings('p.error').show().empty().text('전화번호를 입력해 주세요.');
					return false;
				}

				$('.input-phone-number, .button-send-sms').prop('disabled', true);
				$('.resend-sms').show();
				// $('.send-sms .button-send-sms').prop('disabled', true);

				if ($('.certification-count').text() == '00:00' || $('.certification-count').text() == '') {
					var second = 1000;
					var minute = second * 60 * 5;
					var oneMinute = new Date().getTime() + minute;
					$('.certification-count').countdown(oneMinute).on('update.countdown', function(event) {
						$('.resend-sms .button-resend-sms').prop('disabled', true);
						$(this).text(event.strftime('%M:%S'));
						$(this).text(event.strftime('%M:%S')).closest('.resend-sms').find('.input-certification-number').prop('disabled', false).end().find('.button-certification-complete').prop('disabled', false);
					}).on('finish.countdown', function(event) {
						$(this).text(event.strftime('%M:%S')).closest('.resend-sms').find('.input-certification-number').prop('disabled', true).end().find('.button-certification-complete').prop('disabled', true).end().find('.button-resend-sms').prop('disabled', false);
						alert('시간이 초과 되었습니다.');
					});
				} else {
					$('.resend-sms .button-certification-complete').prop('disabled', true);
				}
			},
			toCheckSms: function() {
				var settings = {
					async: false,
					crossDomain: true,
					url: "http://api.kaicoin.co.kr/auth/sendSMSCode/"+this.selectedCountry+this.phoneNumber,
					method: "GET",
					headers: {
						"content-type": "application/json"
					},
					success : function(data, status, response) {
						if (data) {
							var value = data.requestId;
							let expireDays = 1000 * 60 * 5;

							this.setCookie('__certify', value, expireDays);
						}
					}.bind(this),
					error: function(request, status, error) {
						$('.input-phone-number').siblings('p.error').show().empty().text('전화번호를 입력해 주세요.');
						return false;
					}
				}

				$.ajax(settings).done(function (data,status, xhr) {
					// console.log(xhr.getAllResponseHeaders());
					// console.log(data);
				});
			},
			resendSms: function() {
				// $('.resend-sms').hide();
				// $('.send-sms .input-phone-number').prop('disabled', false);
				// $('.send-sms .button-send-sms').prop('disabled', false)
				// $('.resend-sms .button-resend-sms').prop('disabled', false);
				location.href = "/smsCertification";
			},
			smsCertification: function() {
				var obj = new Object();
				obj.requestId = this.getCookie('__certify');
				obj.smsCode = this.smsCertifyNumber;
				obj.email = this.getCookie('join');

				var json_data = JSON.stringify(obj);

				var settings = {
					async: false,
					crossDomain: true,
					url: "http://api.kaicoin.co.kr/auth/checkSMSCode",
					method: "POST",
					headers: {
						"content-type": "application/json; charset=utf-8"
					},
					processData: true,
					data: json_data,
					success : function(data, status, response) {
						if (data) {
							if (data.isCheck) {
								this.$router.push('/login')
							} else {
								alert('입력이 정확하지 않습니다.')
							}
						}
					}.bind(this),
					error : function(request, status, error) {
						console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
					}
				}

				$.ajax(settings).done(function (data,status, xhr) {
					// console.log(xhr.getAllResponseHeaders());
					// console.log(data);
				});
			}
		}
	}
</script>