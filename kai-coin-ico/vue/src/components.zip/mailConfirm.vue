<template>
	<div></div>
</template>

<script>
	export default {
		created: function() {
			$('header, footer').hide();
		},
		mounted: function() {
			var settings = {
				async: false,
				crossDomain: true,
				url: "/auth/confirmMail/"+this.$route.params.number+"/"+this.$route.params.email+"/",
				method: "GET",
				headers: {},
				success: function() {
					this.$router.push({name: 'smsCertification'});
				}.bind(this), error: function() {
					this.$router.push({name: 'sendMail'});
				}.bind(this)
			}

			$.ajax(settings);
		},
		destroyed: function () {
			$('header, footer').show();
		}
	}
</script>