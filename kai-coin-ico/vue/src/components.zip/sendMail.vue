<template>
	<section class="section-join">
		<article class="mailCertification">
			<h1>카이코인 회원가입</h1>
			<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/KaicoinICO/web/icon-send-mail.png" class="icon-send-mail" alt="" />
			<h2>메일발송 완료</h2>
			<p class="message-send-mail">등록하신 메일주소로<br />
			가입확인 메일을 발송했습니다.<br />
			<em>메일함을 확인해주세요.</em></p>
		</article>
		<div class="button-right">
			<button type="button" class="resend-mail">메일 재발송</button>
		</div>
	</section>
</template>

<script>
	export default {
		name: 'sendMail',
		mounted: function () {
			$('body').addClass('background-gray').removeClass('main');
			$('header').removeClass('main');
		}
	}
</script>