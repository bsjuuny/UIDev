<template>
	<div class="main">
		<div class="bg">
			<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1502962750/KaicoinICO/web/bg_main.png" alt="" />
			<div class="overlay-opacity"></div>
			<div class="overlay-white"></div>
		</div>
		<section>
			<div class="ico-main-title">
				<div class="kaicoin">
					<h2>
						블록체인과 문화의 결합<br />
						<span class="image-kaicoin">kai coin</span> 과 함께하는 거대한 실험
					</h2>
					<p class="kaicoin-infomation">실생활 속에서 블록체인 플랫폼을 체험해보세요.</p>
					<button type="button"><span>ICO</span> 참여</button>
				</div>
				<div class="ico-main-date">
					<h3>2017.10.31 종료(GMT +9시간)</h3>
					<div class="end-countdown">
						<p class="count-time"></p>
						<span class="date day">DAY</span>
						<span class="date hour">HOURS</span>
						<span class="date minute">MINUTES</span>
						<span class="date second">SECONDS</span>
					</div>
					<ul class="coin-infomation">
						<li><em>0</em>/ 2,000,000,000</li>
						<li><strong>1,500 KAI = 1 ETH</strong></li>
					</ul>
				</div>
			</div>
			<div id="about" class="coin-quote">
				<h3><span class="line"></span>"블록체인과 한국 문화 컨텐츠가 결합되어 일상 속에서 다양한 형태로 진화하다!"</h3>
				<p>한국은 IT 강국으로서 새로운 것에 대한 적용이 빠르며 체계적인 통신체계를 갖춘 덕분에 폭넓은 사용환경이 기대되는 국가 중 하나입니다. 분산 시스템이 중요한 역할을 수행하는 세계에서, 비즈니스 및 사회공헌 플랫폼을 통해 사회, 문화, 경제 등 다방면의 활동을 지원하며 많은 성과를 이루어 내고 있습니다. 또한, 실생활에서 가상화폐가 실제로 사용되었을 때 나타나는 문제점들을 파악하고 이에 대비한 솔루션을 연구, 개발 중 입니다.</p>
				<ul>
					<li>
						<span class="image-society"></span>
						<dl>
							<dt>Society</dt>
							<dd>블록체인 기술공유를 통한 사회 인프라 확장<br />사회공헌 플랫폼 구축으로 비영리활동 지원 및<br />NGO단체의 투명한 재정 지원</dd>
						</dl>
					</li>
					<li>
						<span class="image-culture"></span>
						<dl>
							<dt>Culture</dt>
							<dd>K-Culture 컨텐츠를 통해 중국, 일본 마켓팅 플랫폼 구축<br />VR 컨텐츠 및 모바일 동영상 네비게이션 사용 확장<br />음식점, 여행사, 병원 등 오프라인 가맹점 확보<br />국내/외 온라인 쇼핑몰 지원 확대<br />온라인 게임 내부 아이템거래 지원</dd>
						</dl>
					</li>
					<li>
						<span class="image-economy"></span>
						<dl>
							<dt>Economy</dt>
							<dd>KAICOIN 통합거래소 KAIREX 구축<br />현금자동입출금기(ATM)로 KAICOIN 활용<br />국제거래소에 KAICOIN 등재</dd>
						</dl>
					</li>
				</ul>
			</div>
			<div class="contraction">
				<p>일상에서 다양하게 활용가능한 블록체인 기반 시스템을 구축하는 것으로,<br />
				한국의 특색있는 컨텐츠와 문화를 결합하여 사회문화 발전에 기여하고 나아가 국제적으로 통용되는 가상화폐로 인식</p>
			</div>
			<div id="ico" class="coin-introduce-detailinfomation">
				<div class="coin-introduce left">
					<h3><span class="line"></span>KAICOIN 소개</h3>
					<p>가상화폐의 등장으로 일반인들은 새로운 자산형성의 기회를 가지게<br />되었습니다. 이러한 기회를 통해 경제적 불균형과 사회적 비용을<br />획기적으로 개선함과 동시에 금융자산으로서 투자가치를 많은<br />사람들이 나눠가질 수 있도록 가상화폐(암호화폐)를<br />개발하였습니다. KAICOIN은 비트코인과 이더리움의 단점을 보완한<br />진화된 보안알고리즘과 속성들의 최적의 밸런스를 찾았으며, 한국투자자협회(Kaii)에서 개발<br />및 발행합니다. 특히 KAICOIN은 비트코인과 기존의 가상화폐들의<br />문제점인 채굴과정의 어려움, 빈약한 사용환경, 수익실현을 위해서<br />많은 시간과 노력이 소요되는 점을 획기적으로 개선하였습니다. 이를<br />기반으로 전 세계의 문화/경제/사회 속에서 다양하게 활용되는<br />글로벌 대표 코인으로 자리잡을 것입니다.</p>
				</div>
				<div class="coin-detailinfomation right">
					<h3><span class="line"></span>KAICOIN 세부정보</h3>
					<table>
						<thead>
							<tr>
								<th>항목</th>
								<th>내용</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>코인명</td>
								<td>KAICOIN (카이코인)</td>
							</tr>
							<tr>
								<td>코인단위</td>
								<td>KAI</td>
							</tr>
							<tr>
								<td>Presale 기간</td>
								<td>2017-09-01 PM12:00 ~<br />2017-10-31 PM11:59 (GMT+9)</td>
							</tr>
							<tr>
								<td>토큰당 가격</td>
								<td>1,500 KAI = 1 ETH</td>
							</tr>
							<tr>
								<td>최소구매량</td>
								<td>150 KAI = 0.1 ETH 부터 가능</td>
							</tr>
							<tr>
								<td>총 공급량</td>
								<td>200,000,000</td>
							</tr>
							<tr>
								<td>거래가능 화폐</td>
								<td>ETH</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="coin-equity-structure-bonus">
				<div class="coin-equity-structure">
					<h3><span class="line"></span>KAICOIN 지분구조</h3>
					<div class="left">
						<dl>
							<dt>총 공급량</dt>
							<dd class="amount">2,100,000,000</dd>
							<dd class="imagearea"><img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503317491/KaicoinICO/web/total.png" alt="공개채굴량:1,000,000,000/ 선채굴량:1,100,000,000" class="layout-margin" /></dd>
						</dl>
					</div>
					<div class="right">
						<dl>
							<dt>선채굴량</dt>
							<dd class="amount">1,100,000,000</dd>
							<dd class="imagearea"><img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503317490/KaicoinICO/web/first.png" alt="한국 Presale:600,000,000/ ICO:200,000,000/ 사회기부:100,000,000/ 투자자보유:100,000,000/ 기타:100,000,000" /></dd>
						</dl>
					</div>
				</div>
				<div class="coin-bonus">
					<h3><span class="line"></span>보너스</h3>
					<div class="bonus-timetable">
						<p class="week one">1주차 + 20%</p>
						<p class="week two">2주차 + 15%</p>
						<p class="week three">3주차 + 10%</p>
						<p class="week four">4주차 + 5%</p>
						<p class="week five">5주차 + 0%</p>
					</div>
				</div>
			</div>
			<div id="roadmap" class="coin-roadmap">
				<h3><span class="line"></span>로드맵</h3>
				<div class="swiper-button-next"></div>
				<div class="swiper-button-prev"></div>
				<div class="roadmap swiper-container">
					<div class="timeline"></div>
					<div class="swiper-wrapper">
						<div class="swiper-slide">
							<div class="roadmap1">
								<h4>~ 2017.09(현재)</h4>
								<dl>
									<dt>온라인</dt>
									<dd>KAICOIN 개발/ ICO 한국 Pre-sale 완료/<br />
									ICO 글로벌 Pre-sale 런칭/ KAICOIN 기부 약정 체결</dd>
									<dt>오프라인</dt>
									<dd>음식점, 병원, 카드 등 오프라인 가맹점 확보 완료</dd>
									<dt>활용범위</dt>
									<dd>PICK:LE 서비스 (현)/ 영화산업에 코인 투자<br />
									진행 (현)/ 게임 아이템 구매 (현)/ 온라인<br />
									쇼핑몰 (현) / 이디야커피 제휴(현)/ 신한카드<br />
									제휴 (현)/ 음식점, 병원 (현)</dd>
								</dl>
							</div>
						</div>
						<div class="swiper-slide">
							<div class="roadmap1">
								<h4>2017.10~12</h4>
								<dl>
									<dt>온라인</dt>
									<dd>KAICOIN 거래소 KAIREX 런칭/ 국제거래소 등재</dd>
									<dt>오프라인</dt>
									<dd>Vendor, PG업체와 제휴 확대</dd>
									<dt>활용범위</dt>
									<dd>국내 문화산업 전반에 잠입 결제 모듈 지원<br />
									확대/ E-sports 관련 코인 베팅 참여 등<br />
									게임산업 코인 활용도 증대</dd>
								</dl>
							</div>
						</div>
						<div class="swiper-slide">
							<div class="roadmap1">
								<h4>2018</h4>
								<dl>
									<dt>온라인</dt>
									<dd>KAICOIN과 카드의 결합<br />코인으로 간편결제 연동</dd>
									<dt>오프라인</dt>
									<dd>오프라인 가맹점 3,000개 이상 확보</dd>
									<dt>활용범위</dt>
									<dd>일상 속 KAICOIN 사용 생활화<br />현금자동입출금기(ATM)에서 KAICOIN 사용<br />편의점, 도소매점 등에서 직/간접적으로 활용 가능</dd>
								</dl>
							</div>
						</div>
						<div class="swiper-slide">
							<div class="roadmap1">
								<h4>2019</h4>
								<dl>
									<dt>온라인</dt>
									<dd>중국, 일본에 결제시스템 지원</dd>
									<dt>오프라인</dt>
									<dd>오프라인 가맹점 10,000여개 이상 확보</dd>
									<dt>활용범위</dt>
									<dd>여행산업 중심 지원 확대/<br />
									항공, 호텔, 교통 등 전반적인 한국여행을 위한 맞춤<br />
									결제플랫폼/ 중국, 일본인 관광객에 특화된 편의성 제공</dd>
								</dl>
							</div>
						</div>
						<div class="swiper-slide">
							<div class="roadmap1">
								<h4>2020</h4>
								<dl>
									<dt>온라인</dt>
									<dd>국내/외 실생활에서 활용도 높은 화폐규약으로 자리매김</dd>
									<dt>오프라인</dt>
									<dd>중국, 일본 외 동남아 및 유럽시장 진출 모색</dd>
									<dt>활용범위</dt>
									<dd>누구나 쉽고 편리하게 활용할 수 있는 대표적인 가상화폐로<br />인식</dd>
								</dl>
							</div>
						</div>
					</div>
					<!-- Add Arrows -->
				</div>
			</div>
			<div id="team" class="coin-team">
				<h3><span class="line"></span>팀구성</h3>
				<ul class="kaii">
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503034561/KaicoinICO/web/chairman.png" alt="" />
						<strong>박주용 한국투자자협회 Chairman</strong>
						<span>한국투자자협회(Kaii) 설립 카이코인 투자 및 전문 경영</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503034561/KaicoinICO/web/director.png" alt="" />
						<strong>김미남 Director</strong>
						<span>암호화폐별 블록체인 분석 COIN 컨설팅</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503034561/KaicoinICO/web/academydirector.png" alt="" />
						<strong>황선원 KAii Academy Director</strong>
						<span>블록체인과 암호화폐 연구 암호화폐 Business 및 강의</span>
					</li>
				</ul>
				<ul class="greenstage"> 
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503035116/KaicoinICO/web/ceo.png" alt="" />
						<strong>김경민 GREENSTAGE CEO</strong>
						<span>블록체인 전문가 카이코인<br />프로젝트 연구</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503035116/KaicoinICO/web/cto.png" alt="" />
						<strong>조성훈 GREENSTAGE CTO</strong>
						<span>카이코인 프로젝트 리더<br />블록체인기술 부분 리딩<br />전문분야: 데이터베이스,<br />분산서버 프로그래밍 설계,<br />게임서버 설계</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503035116/KaicoinICO/web/pm.png" alt="" />
						<strong>최경은 Project Manager</strong>
						<span>사업 및 전략기획<br />카이코인 서비스 기획</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503035116/KaicoinICO/web/designer.png" alt="" />
						<strong>박가현 Designer</strong>
						<span>웹, 모바일 UI/UX 디자이너<br />카이코인 BI 및 수석디자인 담당</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503035116/KaicoinICO/web/frontend.png" alt="" />
						<strong>백승준 카이코인 frontend UX / UI 개발담당</strong>
						<span>전문분야 : JavaScript Vue.js 웹표준 크로스 브라우징</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503035117/KaicoinICO/web/blockchain.png" alt="" />
						<strong>권순민 Blockchain Engineer</strong>
						<span>카이코인 리모델링 테스트 및 bitcoin 분석가</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503035117/KaicoinICO/web/blockchain1.png" alt="" />
						<strong>한건국 Blockchain Engineer</strong>
						<span>카이코인 서버프로그래밍 담당 및 ethereum 분석가</span>
					</li>
					<li>
						<img src="http://res.cloudinary.com/dhjjs2uz3/image/upload/v1503035116/KaicoinICO/web/hr.png" alt="" />
						<strong>박안나 Assistant</strong>
						<span>회계 및 매니저<br />KAICOIN 사업 관리</span>
					</li>
				</ul>
			</div>
			<div id="faq" class="coin-faq">
				<h3><span class="line"></span>FAQ</h3>
				<dl>
					<dt><a href="#">Q. 카이코인은 무엇인가요?</a></dt>
					<dd>카이코인은 비트코인과 이더리움의 단점을 보안한 슈퍼보안 알고리즘을 채택하고 기존의 토큰 전송속도를 단축시킨, 보안에 중점을 둔 최상의 암호화폐입니다.</dd>
					<dt><a href="#">Q. 누구나 ICO 참여가 가능한가요?</a></dt>
					<dd>미국시민은 참여하실 수 없습니다. 회원가입시 미국시민이 아님을 확인하는 약관에 체크하셔야 가입이 가능합니다.</dd>
					<dt><a href="#">Q. ICO에 어떻게 참여하나요?</a></dt>
					<dd>
						<ul>
							<li>1) 제공된 정보와 백서 등을 꼼꼼히 살펴보신 후</li>
							<li>2) 카이코인 사이트에 회원가입을 하세요.</li>
							<li>3) 로그인을 하신 후 [카이코인 ICO 투자신청서]에 개인 이더리움 주소를 입력하고 신청완료를 합니다.</li>
							<li>4) 페이지 내에 [코인 구매 주소]를 확인합니다. </li>
							<li>5) 개인 이더리움 지갑(MyEtherWallet 추천)을 이용하여, 투자신청서에 기입하신 이더리움 주소로부터 [코인 구매 주소]로 투자하실 이더리움을 보냅니다. (1ETH=1,500KAI)</li>
							<li>6) 참여가 완료되었습니다!</li>
						</ul>
					</dd>
					<dt><a href="#">Q. 구매 가능한 최소/최대량이 정해져있나요?</a></dt>
					<dd>최소 참여량은 0.1ETH 이며 최대량 제한은 없습니다.</dd>
					<dt><a href="#">Q. 참여하면 카이코인이 바로 지급되나요?</a></dt>
					<dd>카이코인 프리세일 기간이 종료될 때까지 지급되지 않습니다. 기간 종료 후 안내와 함께 일괄적으로 지급될 예정입니다.</dd>
					<dt><a href="#">Q. 구매한 이후 내 구매정보를 확인할 수 있나요?</a></dt>
					<dd>카이코인 사이트에 로그인 하시면 페이지 하단에 [카이코인 ICO 참여 확인] 란이 있습니다. 보내신 이더리움 주소를 입력하시면 구매정보를 확인하실 수 있으며, 보다 자세한 내용은 프리세일 기간 종료 후 재안내 드리겠습니다.</dd>
					<dt><a href="#">Q. 카이코인으로 무엇을 할 수 있나요?</a></dt>
					<dd>현재 게임 아이템 구매, 온라인 쇼핑몰, 병원 등의 가맹점을 확보하였고, 문화 컨텐츠와 연계된 전자상거래 부분을 중점으로 온/오프라인 가맹점을 확대해 나갈 예정입니다.</dd>
				</dl>
			</div>
			<div class="partners">
				<h3><span class="line"></span>제휴사</h3>
				<ul class="list-partners">
					<li>KAii</li>
					<li>WHITE STONE</li>
					<li>allreve</li>
					<li>WOWZONE </li>
					<li>PICK:LE 일본</li>
					<li>PICK:LE 중국</li>
					<li>㈜비트앤퍼슨</li>
					<li>AllStarWORLD</li>
					<li>로젠비 메디컬</li>
					<li>미래옥<span class="small">(불고기전문점)</span></li>
					<li>큰물참치</li>
					<li>INCAPO</li>
				</ul>
			</div>
		</section>
	</div>
</template>

<script>
	export default {
		name: 'main',
		data: function() {
			return {
				getAboutTop: 0,
				getIcoTop: 0,
				getRoadmapTop: 0,
				getTeamTop: 0,
				getFaqTop: 0
			}
		},
		created: function () {
			window.addEventListener('scroll', this.headerStyle);
		},
		mounted: function () {
			this.getAboutTop = parseInt($('#about').position().top);
			this.getIcoTop = parseInt($('#ico').position().top);
			this.getRoadmapTop = parseInt($('#roadmap').position().top);
			this.getTeamTop = parseInt($('#team').position().top);
			this.getFaqTop = parseInt($('#faq').position().top);

			$('body').removeClass('background-gray').addClass('main');
			$('header').addClass('main state');

			this.dateCountdown();
			// this.headerStyle();
			this.faq();
			this.bonusTimeLine();

			var swiper = new Swiper('.swiper-container', {
				width: 436,
				nextButton: '.swiper-button-next',
				prevButton: '.swiper-button-prev',
				paginationType: 'progress'
			});
		},
		destroyed: function () {
			window.removeEventListener('scroll', this.headerStyle);
		},
		methods: {
			dateCountdown: function() {
				var icoDate = moment.tz("2017-10-31 12:00:00", "asia/seoul");
				$('.end-countdown .count-time').countdown(icoDate.toDate()).on('update.countdown', function(event) {
					$(this).text(event.strftime('%D : %H : %M : %S'));
				}).on('finish.countdown', function(event) {
					$(this).text(event.strftime('00 : 00 : 00 : 00'));
				});
			},
			headerStyle: function() {
				var windowScrollTop = parseInt($(window).scrollTop()) + 50;
				if (windowScrollTop > 100) {
					$('header').removeClass('main state');
				} else {
					$('header').addClass('main state');
				}

				if (this.getAboutTop > windowScrollTop) {$('header .header-gnb li a').removeClass('active');}
				if (this.getAboutTop - 10 < windowScrollTop && windowScrollTop < this.getIcoTop) {
					$('header .header-gnb li a').removeClass('active');
					$('header .header-gnb li:nth-child(1) a').addClass('active');
				}
				if (this.getIcoTop - 10 < windowScrollTop && windowScrollTop < this.getRoadmapTop) {
					$('header .header-gnb li a').removeClass('active');
					$('header .header-gnb li:nth-child(2) a').addClass('active');
				}
				if (this.getRoadmapTop - 10 < windowScrollTop && windowScrollTop < this.getTeamTop) {
					$('header .header-gnb li a').removeClass('active');
					$('header .header-gnb li:nth-child(3) a').addClass('active');
				}
				if (this.getTeamTop - 10 < windowScrollTop && windowScrollTop < this.getFaqTop) {
					$('header .header-gnb li a').removeClass('active');
					$('header .header-gnb li:nth-child(4) a').addClass('active');
				}
				if (this.getFaqTop - 10 < windowScrollTop) {
					$('header .header-gnb li a').removeClass('active');
					$('header .header-gnb li:nth-child(5) a').addClass('active');
				}
			},
			faq: function() {
				$('.coin-faq dt a').on('click', function(e) {
					e.preventDefault();
					if ($(this).hasClass('active')) {
						$(this).toggleClass('active').closest('dt').next('dd').toggle();	
					} else {
						$('.coin-faq dt a').removeClass('active');
						$('.coin-faq dd').hide();
						$(this).toggleClass('active').closest('dt').next('dd').toggle();	
					}
				});
			},
			bonusTimeLine: function() {
				var startdate1 = moment.tz("2017-09-01 12:00:00", "asia/seoul"),
					enddate1 = moment.tz("2017-09-08 11:59:59", "asia/seoul"),

					startdate2 = moment.tz("2017-09-08 12:00:00", "asia/seoul"),
					enddate2 = moment.tz("2017-09-15 11:59:59", "asia/seoul"),

					startdate3 = moment.tz("2017-09-15 12:00:00", "asia/seoul"),
					enddate3 = moment.tz("2017-09-22 11:59:59", "asia/seoul"),

					startdate4 = moment.tz("2017-09-22 12:00:00", "asia/seoul"),
					enddate4 = moment.tz("2017-09-29 11:59:59", "asia/seoul"),

					startdate5 = moment.tz("2017-09-29 12:00:00", "asia/seoul");

				$('.bonus-timetable .week').removeClass('active');
				if (moment().isBetween(startdate1, enddate1)) {
					$('.bonus-timetable').find('.one').addClass('active');
				} else if (moment().isBetween(startdate2, enddate2)) {
					$('.bonus-timetable').find('.two').addClass('active');
				} else if (moment().isBetween(startdate3, enddate3)) {
					$('.bonus-timetable').find('.three').addClass('active');
				} else if (moment().isBetween(startdate4, enddate4)) {
					$('.bonus-timetable').find('.four').addClass('active');
				} else if (moment().isAfter(startdate5)) {
					$('.bonus-timetable').find('.five').addClass('active');
				};
			}
		}
	}
</script>